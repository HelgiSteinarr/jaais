<div id="text_section">
                <h3>Hafa samband</h3>
                <p>
<a href="mailto:julius@simnet.is"><b>Julius@simnet.is</b></a><br>
Sími <b>772-6840</b> (ekki alltaf einhver við símann)</p>


Einnig er hægt að senda okkur skilaboð á Facebook síðu okkar <a href="https://www.facebook.com/Austfirsk" target="_blank"><b>Austfirsk Köfun</b></a>.


                </p>
            </div>