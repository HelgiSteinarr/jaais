<div id="text_section">
                <h3>Um Okkur</h3>
                <p>
Austfirsk köfun er köfunarstöð sem er að stíga sín fyrstu skref en þrátt fyrir ungan aldur er mikil reynsla af köfun innanborðs. Markmið okkar er að bjóða persónulega og einstaklingsmiðaða þjónustu sem hentar öllum.
<h4>Köfunarnámskeið</h4>
Austfirsk köfun býður uppá margþætt köfunarnám. Við erum með byrjendanámskeið, framhaldsnámskeið og sérhæfingarnámskeið af ýmsu tagi. Notað er kennsluefni frá PADI sem er mjög vandað og gott. Allir nemendur okkar fá svo alþjóðleg köfunarskírteini að námi loknu.
<h4>Búnaður</h4>
Austfirsk Köfun hefur nýlega fengið umboð fyrir Mares köfunarvörur. Mares er einn stærsti framleiðandi köfunarbúnaðar í heiminum í dag. Þetta ítalska fyrirtæki er í fremstu röð með nýjungar á sviði köfunarvara. Í náinni framtíð munum við bjóða uppá þjónustuskoðanir á Mares búnaði svo og viðgerðaþjónustu.
Þar sem við erum lítið fyrirtæki og fengum umboðið í október 2017 eigum við ekki alla hluti á lager en stefnan er auðvitað sú að auka lagerinn smátt og smátt þó að dýrari hlutir verði líklega oftast til í takmörkuðu magni hjá okkur. Til að byrja með verður fyrirkomulagið þannig að pantað verður reglulega inn sá búnaður sem köfurum vantar. 
Til að fá nánari upplýsingar um vörúrval eða betri lýsingu á búnaði sem við bjóðum er hægt að hafa samband við okkur eða líta á heimasíðu Mares.
<a href="www.mares.com" target="_blank"><b>www.mares.com</b></a>
Við getum pantað flest allar vörur sem Mares býður uppá á heimasíðu sinni.
Markmið okkar er að vera samkeppnisfærir.

                </p>
				
            </div>