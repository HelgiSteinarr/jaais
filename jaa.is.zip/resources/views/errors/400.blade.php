<style>
    h1{

    }
</style>
<h1>
    400 - Slæm umsókn <!-- Bad request -->
</h1>
<h2><a href="https://www.jaa.is">Fara á aðalsíðu</a></h2>
<h4>
ef þú heldur að þetta ætti <u>ekki</u> að gerast hafðu samband við <a href="mailto:helgi203@gmail.com">Helgi203@gmail.com</a>
</h4>